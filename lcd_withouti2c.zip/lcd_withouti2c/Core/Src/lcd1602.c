/*
* LCD1602.c
*
*  Created on: Jun 4, 2025
*/

#include "lcd1602.h"
//#include "stm32l4xx_hal_conf.h"

#define LCD_RS_Pin GPIO_PIN_4
#define LCD_RS_Port GPIOB
#define LCD_E_Pin GPIO_PIN_1
#define LCD_E_Port GPIOB
#define LCD_D4_Pin GPIO_PIN_5
#define LCD_D4_Port GPIOC
#define LCD_D5_Pin GPIO_PIN_4
#define LCD_D5_Port GPIOC
#define LCD_D6_Pin GPIO_PIN_3
#define LCD_D6_Port GPIOC
#define LCD_D7_Pin GPIO_PIN_2
#define LCD_D7_Port GPIOC


void delay(uint16_t us)
{
	uint16_t s = 0;
	while(s < us)
	{
		s++;
	}
}

void send_to_lcd(char data,uint8_t rs)
{
	//rs = 1 Data , rs = 0 Instruction(command)
	HAL_GPIO_WritePin(LCD_RS_Port, LCD_RS_Pin, rs);

	/* Write data to respective pins */
	HAL_GPIO_WritePin(LCD_D7_Port, LCD_D7_Pin, ((data>>3)&0x01));
	HAL_GPIO_WritePin(LCD_D6_Port, LCD_D6_Pin, ((data>>2)&0x01));
	HAL_GPIO_WritePin(LCD_D5_Port, LCD_D5_Pin, ((data>>1)&0x01));
	HAL_GPIO_WritePin(LCD_D4_Port, LCD_D4_Pin, ((data>>0)&0x01));

	// Toggle Enable pin
	HAL_GPIO_WritePin(LCD_E_Port, LCD_E_Pin, 1);
	HAL_Delay(10);
	HAL_GPIO_WritePin(LCD_E_Port, LCD_E_Pin, 0);
	HAL_Delay(10);

}


void lcd_send_cmd(char cmd)
{
	char cmdSend;

	//send upper nibble
	cmdSend = ((cmd >> 4) & 0x0f);
	send_to_lcd(cmdSend, 0);	//RS = 0 for command

	//send lower nibble
	cmdSend = (cmd & 0x0f);
	send_to_lcd(cmdSend, 0);	//RS = 0 for command
}

void lcd_send_data(char data)
{
	char dataSend;

	//send upper nibble
	dataSend = ((data >> 4) & 0x0f);
	send_to_lcd(dataSend, 1);	//RS = 1 for data

	//send lower nibble
	dataSend = (data & 0x0f);
	send_to_lcd(dataSend, 1);	//RS = 1 for data
}

void lcd_clear(void)
{
	lcd_send_cmd(0x01); //0x01 Command to Clear display screen
	HAL_Delay(2);		// Clear command takes longer to execute
}

void lcd_put_cur(uint8_t row, uint8_t col)
{
	switch(row)
	{
		case 0:
			col |= 0x80;
			break;
		case 1:
			col |= 0xC0;
			break;
	}

	lcd_send_cmd (col);
}

void lcd_Init(void)
{
	HAL_Delay(50); 		// Wait for LCD to power up
	lcd_send_cmd(0x02);	// Initialize in 4-bit mode
	HAL_Delay(20);
	lcd_send_cmd(0x28);	// 2 lines, 5x8 font
	HAL_Delay(20);
	lcd_send_cmd(0x08);	// Display OFF, cursor OFF
	HAL_Delay(20);
	lcd_send_cmd(0x01);	// Clear display
	HAL_Delay(20);
	lcd_send_cmd(0x06);	// Entry mode: Increment cursor
	HAL_Delay(20);
	lcd_send_cmd(0x0c);	// Display ON, cursor OFF
	HAL_Delay(20);
}

void lcd_send_string(char *str)
{
	while(*str)
	{
		lcd_send_data(*str++);
	}
}
