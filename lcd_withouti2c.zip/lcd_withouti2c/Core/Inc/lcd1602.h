/*
 * lcd1602.h
 *
 *  Created on: Jun 18, 2025
 *      Author: 166870
 */

#ifndef INC_LCD1602_H_
#define INC_LCD1602_H_

#include "stm32l4xx_hal.h"

void lcd_Init(void);					//Initialise lcd

void lcd_send_cmd(char cmd);			//send command to lcd

void lcd_send_data(char data);			//send data to lcd

void send_to_lcd(char data,uint8_t rs);		//send data or command to lcd

void lcd_put_cur(uint8_t row, uint8_t col);		//put curser at entered location row (0 or 1) , col (0 - 15)

void lcd_send_string(char *str);		//send string to lcd

void lcd_clear(void);

#endif /* INC_LCD1602_H_ */
